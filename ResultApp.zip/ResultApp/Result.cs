﻿using System;

namespace ResultApp
{
    public class Result : Exam, Classify
    {
        // Implement Pass method
        public bool Pass(int mark)
        {
            return mark >= 50;
        }

        // Implement Division method
        public string Division(int average)
        {
            if (average >= 60)
                return "First";
            else if (average >= 50)
                return "Second";
            else
                return "No division";
        }
    }
}