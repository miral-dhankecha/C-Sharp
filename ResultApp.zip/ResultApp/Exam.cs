﻿namespace ResultApp
{
    public interface Exam
    {
        bool Pass(int mark);
    }
}