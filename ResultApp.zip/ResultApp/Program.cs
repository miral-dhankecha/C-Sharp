﻿using System;

namespace ResultApp
{
    class Program
    {
        static void Main(string[] args)
        {
            Result r = new Result();

            int marks = 55;
            int average = 58;

            // Check Pass/Fail
            if (r.Pass(marks))
                Console.WriteLine("Result: Pass");
            else
                Console.WriteLine("Result: Fail");

            // Check Division
            Console.WriteLine("Division: " + r.Division(average));

            Console.ReadLine();
        }
    }
}