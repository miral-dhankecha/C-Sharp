﻿namespace ResultApp
{
    public interface Classify
    {
        string Division(int average);
    }
}