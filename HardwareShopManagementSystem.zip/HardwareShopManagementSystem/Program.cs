﻿using System;
using System.Windows.Forms;

namespace HardwareShopManagementSystem
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // 👇 YAHI IMPORTANT LINE HAI
            Application.Run(new LoginForm());
        }
    }
}