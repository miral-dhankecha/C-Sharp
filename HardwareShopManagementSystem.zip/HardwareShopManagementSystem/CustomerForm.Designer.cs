﻿namespace HardwareShopManagementSystem
{
    partial class CustomerForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.Panel panelSidebar;
        private System.Windows.Forms.Panel panelTop;
        private System.Windows.Forms.Label lblTitle;
        private System.Windows.Forms.Label lblCustomerName;
        private System.Windows.Forms.Label lblPhone;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox txtCustomer;
        private System.Windows.Forms.TextBox txtPhone;
        private System.Windows.Forms.TextBox txtAddress;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.DataGridView dgvCustomer;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelSidebar = new System.Windows.Forms.Panel();
            this.panelTop = new System.Windows.Forms.Panel();
            this.lblTitle = new System.Windows.Forms.Label();
            this.lblCustomerName = new System.Windows.Forms.Label();
            this.lblPhone = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.txtCustomer = new System.Windows.Forms.TextBox();
            this.txtPhone = new System.Windows.Forms.TextBox();
            this.txtAddress = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.dgvCustomer = new System.Windows.Forms.DataGridView();

            this.panelSidebar.SuspendLayout();
            this.panelTop.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).BeginInit();
            this.SuspendLayout();

            // Panel Sidebar
            this.panelSidebar.BackColor = System.Drawing.Color.FromArgb(30, 30, 60);
            this.panelSidebar.Dock = System.Windows.Forms.DockStyle.Left;
            this.panelSidebar.Width = 200;

            // Panel Top
            this.panelTop.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelTop.Dock = System.Windows.Forms.DockStyle.Top;
            this.panelTop.Height = 60;

            // lblTitle
            this.lblTitle.Text = "Customers";
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.AutoSize = true;
            this.lblTitle.Location = new System.Drawing.Point(220, 15);
            this.panelTop.Controls.Add(this.lblTitle);

            // Labels
            this.lblCustomerName.Text = "Customer Name";
            this.lblCustomerName.Location = new System.Drawing.Point(220, 60);
            this.lblCustomerName.AutoSize = true;

            this.lblPhone.Text = "Phone";
            this.lblPhone.Location = new System.Drawing.Point(220, 100);
            this.lblPhone.AutoSize = true;

            this.lblAddress.Text = "Address";
            this.lblAddress.Location = new System.Drawing.Point(220, 140);
            this.lblAddress.AutoSize = true;

            // Textboxes
            this.txtCustomer.Location = new System.Drawing.Point(220, 80);
            this.txtCustomer.Size = new System.Drawing.Size(300, 30);
            this.txtCustomer.Font = new System.Drawing.Font("Segoe UI", 11F);

            this.txtPhone.Location = new System.Drawing.Point(220, 120);
            this.txtPhone.Size = new System.Drawing.Size(300, 30);
            this.txtPhone.Font = new System.Drawing.Font("Segoe UI", 11F);

            this.txtAddress.Location = new System.Drawing.Point(220, 160);
            this.txtAddress.Size = new System.Drawing.Size(300, 30);
            this.txtAddress.Font = new System.Drawing.Font("Segoe UI", 11F);

            // Buttons
            int btnWidth = 100;
            int btnHeight = 35;
            int btnTop = 200;

            this.btnAdd.Text = "Add";
            this.btnAdd.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnAdd.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnAdd.Location = new System.Drawing.Point(220, btnTop);
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);

            this.btnUpdate.Text = "Update";
            this.btnUpdate.BackColor = System.Drawing.Color.CornflowerBlue;
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnUpdate.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnUpdate.Location = new System.Drawing.Point(330, btnTop);
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);

            this.btnDelete.Text = "Delete";
            this.btnDelete.BackColor = System.Drawing.Color.IndianRed;
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Size = new System.Drawing.Size(btnWidth, btnHeight);
            this.btnDelete.Location = new System.Drawing.Point(440, btnTop);
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);

            // DataGridView
            this.dgvCustomer.Location = new System.Drawing.Point(220, 260);
            this.dgvCustomer.Size = new System.Drawing.Size(600, 300);
            this.dgvCustomer.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dgvCustomer.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCustomer.ReadOnly = true;
            this.dgvCustomer.AllowUserToAddRows = false;
            this.dgvCustomer.AllowUserToDeleteRows = false;
            this.dgvCustomer.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCustomer_CellClick);

            // Form
            this.ClientSize = new System.Drawing.Size(900, 600);
            this.Controls.Add(this.panelSidebar);
            this.Controls.Add(this.panelTop);
            this.Controls.Add(this.lblCustomerName);
            this.Controls.Add(this.lblPhone);
            this.Controls.Add(this.lblAddress);
            this.Controls.Add(this.txtCustomer);
            this.Controls.Add(this.txtPhone);
            this.Controls.Add(this.txtAddress);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);
            this.Controls.Add(this.dgvCustomer);

            this.Text = "Customer Management";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.WindowState = System.Windows.Forms.FormWindowState.Normal;

            this.panelSidebar.ResumeLayout(false);
            this.panelTop.ResumeLayout(false);
            this.panelTop.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvCustomer)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}