﻿namespace HardwareShopManagementSystem
{
    partial class CategoryForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvCategory;
        private System.Windows.Forms.TextBox txtCategoryName;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.Label lblCategoryName;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvCategory = new System.Windows.Forms.DataGridView();
            this.txtCategoryName = new System.Windows.Forms.TextBox();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.lblCategoryName = new System.Windows.Forms.Label();

            ((System.ComponentModel.ISupportInitialize)(this.dgvCategory)).BeginInit();
            this.SuspendLayout();

            // dgvCategory
            this.dgvCategory.Location = new System.Drawing.Point(30, 150);
            this.dgvCategory.Size = new System.Drawing.Size(500, 250);
            this.dgvCategory.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvCategory.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvCategory_CellClick);

            // Label
            this.lblCategoryName.Text = "Category Name";
            this.lblCategoryName.Location = new System.Drawing.Point(30, 20);
            this.lblCategoryName.AutoSize = true;

            // TextBox
            this.txtCategoryName.Location = new System.Drawing.Point(30, 50);
            this.txtCategoryName.Size = new System.Drawing.Size(200, 23);
            this.txtCategoryName.Name = "txtCategoryName";

            // Buttons
            this.btnAdd.Text = "Add";
            this.btnAdd.BackColor = System.Drawing.Color.Green;
            this.btnAdd.ForeColor = System.Drawing.Color.White;
            this.btnAdd.Location = new System.Drawing.Point(250, 50);
            this.btnAdd.Size = new System.Drawing.Size(80, 30);
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);

            this.btnUpdate.Text = "Update";
            this.btnUpdate.BackColor = System.Drawing.Color.Orange;
            this.btnUpdate.ForeColor = System.Drawing.Color.White;
            this.btnUpdate.Location = new System.Drawing.Point(340, 50);
            this.btnUpdate.Size = new System.Drawing.Size(80, 30);
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);

            this.btnDelete.Text = "Delete";
            this.btnDelete.BackColor = System.Drawing.Color.Red;
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(430, 50);
            this.btnDelete.Size = new System.Drawing.Size(80, 30);
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);

            // Form
            this.ClientSize = new System.Drawing.Size(600, 450);
            this.Controls.Add(this.dgvCategory);
            this.Controls.Add(this.lblCategoryName);
            this.Controls.Add(this.txtCategoryName);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.btnDelete);

            this.Text = "Category Management";
            this.Load += new System.EventHandler(this.CategoryForm_Load);

            ((System.ComponentModel.ISupportInitialize)(this.dgvCategory)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}