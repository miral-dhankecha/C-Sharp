﻿namespace HardwareShopManagementSystem
{
    partial class InvoiceForm
    {
        private System.ComponentModel.IContainer components = null;
        private System.Windows.Forms.DataGridView dgvInvoice;
        private System.Windows.Forms.Button btnPrint;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvInvoice = new System.Windows.Forms.DataGridView();
            this.btnPrint = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoice)).BeginInit();
            this.SuspendLayout();

            // FORM
            this.ClientSize = new System.Drawing.Size(600, 400);
            this.Text = "Invoice";

            // GRID
            dgvInvoice.Location = new System.Drawing.Point(20, 20);
            dgvInvoice.Size = new System.Drawing.Size(550, 250);

            // BUTTON
            btnPrint.Text = "Print Bill";
            btnPrint.BackColor = System.Drawing.Color.Green;
            btnPrint.ForeColor = System.Drawing.Color.White;
            btnPrint.Location = new System.Drawing.Point(20, 300);
            btnPrint.Click += new System.EventHandler(this.btnPrint_Click);

            // ADD
            this.Controls.Add(dgvInvoice);
            this.Controls.Add(btnPrint);

            this.Load += new System.EventHandler(this.InvoiceForm_Load);

            ((System.ComponentModel.ISupportInitialize)(this.dgvInvoice)).EndInit();
            this.ResumeLayout(false);
        }
    }
}