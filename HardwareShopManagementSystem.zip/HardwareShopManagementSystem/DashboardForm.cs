﻿using System;
using System.Linq;
using System.Windows.Forms;

namespace HardwareShopManagementSystem
{
    public partial class DashboardForm : Form
    {
        public DashboardForm()
        {
            InitializeComponent();
        }

        private void btnItems_Click(object sender, EventArgs e)
        {
            OpenForm(typeof(ItemForm));
        }

        private void btnCategories_Click(object sender, EventArgs e)
        {
            OpenForm(typeof(CategoryForm));
        }

        private void btnCustomers_Click(object sender, EventArgs e)
        {
            OpenForm(typeof(CustomerForm));
        }

        private void btnBilling_Click(object sender, EventArgs e)
        {
            OpenForm(typeof(BillingForm));
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            var result = MessageBox.Show("Are you sure you want to logout?", "Logout", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }

        private void OpenForm(Type formType)
        {
            Form existingForm = Application.OpenForms.Cast<Form>().FirstOrDefault(f => f.GetType() == formType);

            if (existingForm != null)
            {
                existingForm.BringToFront();
                existingForm.Focus();
                return;
            }

            Form form = (Form)Activator.CreateInstance(formType);
            form.Show();
        }
    }
}