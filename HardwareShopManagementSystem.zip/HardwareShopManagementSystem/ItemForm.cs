﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HardwareShopManagementSystem
{
    public partial class ItemForm : Form
    {
        int selectedId = -1;
        Database db = new Database();

        public ItemForm()
        {
            InitializeComponent();
        }

        private void ItemForm_Load(object sender, EventArgs e)
        {
            LoadCategories();
            LoadItems();
        }

        // ---------------- LOAD CATEGORIES ----------------
        void LoadCategories()
        {
            using (SqlConnection con = db.GetConnection())
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Categories", con);
                DataTable dt = new DataTable();
                da.Fill(dt);

                cmbCategory.DisplayMember = "CategoryName";
                cmbCategory.ValueMember = "CategoryID";
                cmbCategory.DataSource = dt;
            }
        }

        // ---------------- LOAD ITEMS ----------------
        void LoadItems()
        {
            using (SqlConnection con = db.GetConnection())
            {
                con.Open();
                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT ItemID, ItemName, CategoryName, Price, Quantity FROM Items INNER JOIN Categories ON Items.CategoryID = Categories.CategoryID",
                    con);

                DataTable dt = new DataTable();
                da.Fill(dt);
                dgvItems.DataSource = dt;
            }
        }

        // ---------------- ADD ----------------
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                using (SqlConnection con = db.GetConnection())
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand(
                        "INSERT INTO Items (ItemName, CategoryID, Price, Quantity) VALUES (@name,@cat,@price,@qty)", con);

                    cmd.Parameters.AddWithValue("@name", txtItemName.Text);
                    cmd.Parameters.AddWithValue("@cat", cmbCategory.SelectedValue);
                    cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                    cmd.Parameters.AddWithValue("@qty", txtQuantity.Text);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Item Added!");
                    LoadItems();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // ---------------- CELL CLICK (FIXED) ----------------
        private void dgvItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                if (e.RowIndex < 0) return;

                var row = dgvItems.Rows[e.RowIndex];

                // NULL SAFE CHECK
                if (row.Cells[0].Value == null || row.Cells[0].Value == DBNull.Value)
                {
                    MessageBox.Show("Invalid ID (NULL)");
                    selectedId = -1;
                    return;
                }

                // SAFE CONVERSION
                if (int.TryParse(row.Cells[0].Value.ToString(), out int id))
                {
                    selectedId = id;
                }
                else
                {
                    MessageBox.Show("Invalid ID format");
                    selectedId = -1;
                    return;
                }

                // TEXT FILL SAFE
                txtItemName.Text = row.Cells[1].Value?.ToString() ?? "";
                txtPrice.Text = row.Cells[3].Value?.ToString() ?? "";
                txtQuantity.Text = row.Cells[4].Value?.ToString() ?? "";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // ---------------- UPDATE ----------------
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedId <= 0)
            {
                MessageBox.Show("Please select valid item");
                return;
            }

            try
            {
                using (SqlConnection con = db.GetConnection())
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand(
                        "UPDATE Items SET ItemName=@name, CategoryID=@cat, Price=@price, Quantity=@qty WHERE ItemID=@id", con);

                    cmd.Parameters.AddWithValue("@name", txtItemName.Text);
                    cmd.Parameters.AddWithValue("@cat", cmbCategory.SelectedValue);
                    cmd.Parameters.AddWithValue("@price", txtPrice.Text);
                    cmd.Parameters.AddWithValue("@qty", txtQuantity.Text);
                    cmd.Parameters.AddWithValue("@id", selectedId);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Item Updated!");
                    LoadItems();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }

        // ---------------- DELETE ----------------
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId <= 0)
            {
                MessageBox.Show("Please select valid item");
                return;
            }

            try
            {
                using (SqlConnection con = db.GetConnection())
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("DELETE FROM Items WHERE ItemID=@id", con);
                    cmd.Parameters.AddWithValue("@id", selectedId);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Item Deleted!");
                    LoadItems();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error: " + ex.Message);
            }
        }
    }
}