﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HardwareShopManagementSystem
{
    public partial class BillingForm : Form
    {
        Database db = new Database();
        decimal grandTotal = 0;

        public BillingForm()
        {
            InitializeComponent();
        }

        private void BillingForm_Load(object sender, EventArgs e)
        {
            LoadCustomers();
            LoadItems();
            SetupBillGrid();
        }

        // ✅ Bill Grid
        private void SetupBillGrid()
        {
            dgvBill.Columns.Clear();
            dgvBill.AllowUserToAddRows = false;

            dgvBill.Columns.Add("ItemID", "ItemID");
            dgvBill.Columns.Add("ItemName", "Item Name");
            dgvBill.Columns.Add("Price", "Price");
            dgvBill.Columns.Add("Qty", "Quantity");
            dgvBill.Columns.Add("Total", "Total");

            dgvBill.Columns["ItemID"].Visible = false;
        }

        // ✅ Load Customers
        private void LoadCustomers()
        {
            using (SqlConnection con = db.GetConnection())
            {
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT CustomerID, CustomerName FROM Customers", con);

                DataTable dt = new DataTable();
                da.Fill(dt);

                // 🔥 Default row
                DataRow row = dt.NewRow();
                row["CustomerID"] = 0;
                row["CustomerName"] = "-- Select Customer --";
                dt.Rows.InsertAt(row, 0);

                cmbCustomer.DataSource = dt;
                cmbCustomer.DisplayMember = "CustomerName";
                cmbCustomer.ValueMember = "CustomerID";
            }
        }

        // ✅ Load Items
        private void LoadItems()
        {
            using (SqlConnection con = db.GetConnection())
            {
                con.Open();

                SqlDataAdapter da = new SqlDataAdapter(
                    "SELECT ItemID, ItemName, Price FROM Items", con);

                DataTable dt = new DataTable();
                da.Fill(dt);

                dgvItems.DataSource = dt;
                dgvItems.Columns["ItemID"].Visible = false;

                cmbItem.DataSource = dt.Copy();
                cmbItem.DisplayMember = "ItemName";
                cmbItem.ValueMember = "ItemID";
            }
        }

        // ✅ Add Item
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (cmbItem.SelectedIndex == -1 ||
                string.IsNullOrWhiteSpace(txtQty.Text) ||
                string.IsNullOrWhiteSpace(txtPrice.Text))
            {
                MessageBox.Show("Please fill all fields!");
                return;
            }

            int itemId = Convert.ToInt32(cmbItem.SelectedValue);
            int qty = Convert.ToInt32(txtQty.Text);
            decimal price = Convert.ToDecimal(txtPrice.Text);

            decimal total = price * qty;

            dgvBill.Rows.Add(itemId, cmbItem.Text, price, qty, total);

            grandTotal += total;
            lblTotal.Text = "Total: ₹ " + grandTotal;
        }

        // ✅ Clear
        private void btnClear_Click(object sender, EventArgs e)
        {
            dgvBill.Rows.Clear();
            grandTotal = 0;
            lblTotal.Text = "Total: ₹ 0";
        }

        // ✅ Save Bill
        private void btnSave_Click(object sender, EventArgs e)
        {
            if (Convert.ToInt32(cmbCustomer.SelectedValue) == 0)
            {
                MessageBox.Show("Please select customer!");
                return;
            }

            if (dgvBill.Rows.Count == 0)
            {
                MessageBox.Show("Please add items first!");
                return;
            }

            using (SqlConnection con = db.GetConnection())
            {
                con.Open();
                SqlTransaction trans = con.BeginTransaction();

                try
                {
                    int customerId = Convert.ToInt32(cmbCustomer.SelectedValue);

                    SqlCommand billCmd = new SqlCommand(
                        "INSERT INTO Bills (CustomerID, Date, TotalAmount) OUTPUT INSERTED.BillID VALUES (@cust, GETDATE(), @total)",
                        con, trans);

                    billCmd.Parameters.AddWithValue("@cust", customerId);
                    billCmd.Parameters.AddWithValue("@total", grandTotal);

                    int billId = (int)billCmd.ExecuteScalar();

                    foreach (DataGridViewRow row in dgvBill.Rows)
                    {
                        int itemId = Convert.ToInt32(row.Cells[0].Value);
                        int qty = Convert.ToInt32(row.Cells[3].Value);
                        decimal price = Convert.ToDecimal(row.Cells[2].Value);
                        decimal total = Convert.ToDecimal(row.Cells[4].Value);

                        SqlCommand itemCmd = new SqlCommand(
                            "INSERT INTO BillItems (BillID, ItemID, Quantity, Price, Total) VALUES (@billId, @itemId, @qty, @price, @total)",
                            con, trans);

                        itemCmd.Parameters.AddWithValue("@billId", billId);
                        itemCmd.Parameters.AddWithValue("@itemId", itemId);
                        itemCmd.Parameters.AddWithValue("@qty", qty);
                        itemCmd.Parameters.AddWithValue("@price", price);
                        itemCmd.Parameters.AddWithValue("@total", total);

                        itemCmd.ExecuteNonQuery();
                    }

                    trans.Commit();

                    MessageBox.Show("Bill Saved Successfully!");

                    // ✅ Open Invoice
                    InvoiceForm invoice = new InvoiceForm(billId);
                    invoice.Show();

                    btnClear.PerformClick();
                }
                catch (Exception ex)
                {
                    trans.Rollback();
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // ✅ Select item from grid
        private void dgvItems_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvItems.Rows[e.RowIndex];

                cmbItem.Text = row.Cells["ItemName"].Value.ToString();
                txtPrice.Text = row.Cells["Price"].Value.ToString();
                txtQty.Text = "1";
            }
        }
    }
}