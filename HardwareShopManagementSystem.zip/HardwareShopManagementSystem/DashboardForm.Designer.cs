﻿using System.Windows.Forms;

namespace HardwareShopManagementSystem
{
    partial class DashboardForm : Form
    {
        private System.ComponentModel.IContainer components = null;
        private Panel panelSidebar;
        private Panel panelTop;
        private Label lblTitle;
        private Button btnItems;
        private Button btnCategories;
        private Button btnCustomers;
        private Button btnBilling;
        private Button btnLogout;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.panelSidebar = new Panel();
            this.btnItems = new Button();
            this.btnCategories = new Button();
            this.btnCustomers = new Button();
            this.btnBilling = new Button();
            this.btnLogout = new Button();
            this.panelTop = new Panel();
            this.lblTitle = new Label();

            this.panelSidebar.SuspendLayout();
            this.panelTop.SuspendLayout();
            this.SuspendLayout();

            // ---------------- Sidebar ----------------
            this.panelSidebar.BackColor = System.Drawing.Color.FromArgb(30, 30, 60);
            this.panelSidebar.Dock = DockStyle.Left;
            this.panelSidebar.Width = 200;

            // Items Button
            this.btnItems.Text = "Items";
            this.btnItems.ForeColor = System.Drawing.Color.White;
            this.btnItems.BackColor = System.Drawing.Color.Transparent;
            this.btnItems.FlatStyle = FlatStyle.Flat;
            this.btnItems.Location = new System.Drawing.Point(20, 80);
            this.btnItems.Size = new System.Drawing.Size(160, 40);
            this.btnItems.Click += new System.EventHandler(this.btnItems_Click);

            // Categories Button
            this.btnCategories.Text = "Categories";
            this.btnCategories.ForeColor = System.Drawing.Color.White;
            this.btnCategories.FlatStyle = FlatStyle.Flat;
            this.btnCategories.Location = new System.Drawing.Point(20, 140);
            this.btnCategories.Size = new System.Drawing.Size(160, 40);
            this.btnCategories.Click += new System.EventHandler(this.btnCategories_Click);

            // Customers Button
            this.btnCustomers.Text = "Customers";
            this.btnCustomers.ForeColor = System.Drawing.Color.White;
            this.btnCustomers.FlatStyle = FlatStyle.Flat;
            this.btnCustomers.Location = new System.Drawing.Point(20, 200);
            this.btnCustomers.Size = new System.Drawing.Size(160, 40);
            this.btnCustomers.Click += new System.EventHandler(this.btnCustomers_Click);

            // Billing Button
            this.btnBilling.Text = "Billing";
            this.btnBilling.ForeColor = System.Drawing.Color.White;
            this.btnBilling.FlatStyle = FlatStyle.Flat;
            this.btnBilling.Location = new System.Drawing.Point(20, 260);
            this.btnBilling.Size = new System.Drawing.Size(160, 40);
            this.btnBilling.Click += new System.EventHandler(this.btnBilling_Click);

            // Logout Button
            this.btnLogout.Text = "Logout";
            this.btnLogout.ForeColor = System.Drawing.Color.White;
            this.btnLogout.FlatStyle = FlatStyle.Flat;
            this.btnLogout.Location = new System.Drawing.Point(20, 320);
            this.btnLogout.Size = new System.Drawing.Size(160, 40);
            this.btnLogout.Click += new System.EventHandler(this.btnLogout_Click);

            this.panelSidebar.Controls.Add(this.btnItems);
            this.panelSidebar.Controls.Add(this.btnCategories);
            this.panelSidebar.Controls.Add(this.btnCustomers);
            this.panelSidebar.Controls.Add(this.btnBilling);
            this.panelSidebar.Controls.Add(this.btnLogout);

            // ---------------- Top Panel ----------------
            this.panelTop.BackColor = System.Drawing.Color.RoyalBlue;
            this.panelTop.Dock = DockStyle.Top;
            this.panelTop.Height = 60;

            this.lblTitle.Text = "Dashboard";
            this.lblTitle.ForeColor = System.Drawing.Color.White;
            this.lblTitle.Font = new System.Drawing.Font("Segoe UI", 16F, System.Drawing.FontStyle.Bold);
            this.lblTitle.Location = new System.Drawing.Point(220, 10);
            this.lblTitle.AutoSize = true;

            this.panelTop.Controls.Add(this.lblTitle);

            // ---------------- Form ----------------
            this.Controls.Add(this.panelSidebar);
            this.Controls.Add(this.panelTop);
            this.Text = "Dashboard";
            this.WindowState = FormWindowState.Maximized;
            this.StartPosition = FormStartPosition.CenterScreen;

            this.panelSidebar.ResumeLayout(false);
            this.panelTop.ResumeLayout(false);
            this.ResumeLayout(false);
        }
    }
}