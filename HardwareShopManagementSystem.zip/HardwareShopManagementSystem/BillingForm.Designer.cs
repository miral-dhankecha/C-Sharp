﻿namespace HardwareShopManagementSystem
{
    partial class BillingForm
    {
        private System.ComponentModel.IContainer components = null;

        private System.Windows.Forms.DataGridView dgvItems;
        private System.Windows.Forms.DataGridView dgvBill;
        private System.Windows.Forms.ComboBox cmbCustomer;
        private System.Windows.Forms.ComboBox cmbItem;
        private System.Windows.Forms.TextBox txtPrice;
        private System.Windows.Forms.TextBox txtQty;
        private System.Windows.Forms.Label lblCustomer;
        private System.Windows.Forms.Label lblItem;
        private System.Windows.Forms.Label lblPrice;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblTotal;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.Button btnClear;
        private System.Windows.Forms.Button btnSave;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
                components.Dispose();

            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.dgvItems = new System.Windows.Forms.DataGridView();
            this.dgvBill = new System.Windows.Forms.DataGridView();
            this.cmbCustomer = new System.Windows.Forms.ComboBox();
            this.cmbItem = new System.Windows.Forms.ComboBox();
            this.txtPrice = new System.Windows.Forms.TextBox();
            this.txtQty = new System.Windows.Forms.TextBox();
            this.lblCustomer = new System.Windows.Forms.Label();
            this.lblItem = new System.Windows.Forms.Label();
            this.lblPrice = new System.Windows.Forms.Label();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.lblTotal = new System.Windows.Forms.Label();
            this.btnAdd = new System.Windows.Forms.Button();
            this.btnClear = new System.Windows.Forms.Button();
            this.btnSave = new System.Windows.Forms.Button();

            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBill)).BeginInit();

            this.SuspendLayout();

            // dgvItems
            this.dgvItems.Location = new System.Drawing.Point(20, 60);
            this.dgvItems.Size = new System.Drawing.Size(400, 200);
            this.dgvItems.ReadOnly = true;
            this.dgvItems.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dgvItems.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvItems_CellClick);

            // dgvBill
            this.dgvBill.Location = new System.Drawing.Point(450, 100);
            this.dgvBill.Size = new System.Drawing.Size(500, 300);
            this.dgvBill.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;

            // Labels
            this.lblCustomer.Text = "Customer";
            this.lblCustomer.Location = new System.Drawing.Point(450, 10);

            this.lblItem.Text = "Item";
            this.lblItem.Location = new System.Drawing.Point(450, 50);

            this.lblPrice.Text = "Price";
            this.lblPrice.Location = new System.Drawing.Point(710, 50);

            this.lblQuantity.Text = "Qty";
            this.lblQuantity.Location = new System.Drawing.Point(820, 50);

            // Controls
            this.cmbCustomer.Location = new System.Drawing.Point(450, 25);
            this.cmbCustomer.Size = new System.Drawing.Size(250, 25);

            this.cmbItem.Location = new System.Drawing.Point(450, 70);
            this.cmbItem.Size = new System.Drawing.Size(250, 25);

            this.txtPrice.Location = new System.Drawing.Point(710, 70);
            this.txtPrice.Size = new System.Drawing.Size(100, 25);

            this.txtQty.Location = new System.Drawing.Point(820, 70);
            this.txtQty.Size = new System.Drawing.Size(60, 25);

            // Buttons
            this.btnAdd.Text = "Add";
            this.btnAdd.Location = new System.Drawing.Point(890, 70);
            this.btnAdd.Click += new System.EventHandler(this.btnAdd_Click);

            this.btnClear.Text = "Clear";
            this.btnClear.Location = new System.Drawing.Point(650, 420);
            this.btnClear.Click += new System.EventHandler(this.btnClear_Click);

            this.btnSave.Text = "Save";
            this.btnSave.Location = new System.Drawing.Point(750, 420);
            this.btnSave.Click += new System.EventHandler(this.btnSave_Click);

            // Total
            this.lblTotal.Text = "Total: ₹ 0";
            this.lblTotal.Location = new System.Drawing.Point(450, 420);

            // Form
            this.ClientSize = new System.Drawing.Size(1000, 500);
            this.Controls.Add(this.dgvItems);
            this.Controls.Add(this.dgvBill);
            this.Controls.Add(this.cmbCustomer);
            this.Controls.Add(this.cmbItem);
            this.Controls.Add(this.txtPrice);
            this.Controls.Add(this.txtQty);
            this.Controls.Add(this.lblCustomer);
            this.Controls.Add(this.lblItem);
            this.Controls.Add(this.lblPrice);
            this.Controls.Add(this.lblQuantity);
            this.Controls.Add(this.lblTotal);
            this.Controls.Add(this.btnAdd);
            this.Controls.Add(this.btnClear);
            this.Controls.Add(this.btnSave);

            this.Text = "Billing";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Load += new System.EventHandler(this.BillingForm_Load);

            ((System.ComponentModel.ISupportInitialize)(this.dgvItems)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgvBill)).EndInit();

            this.ResumeLayout(false);
            this.PerformLayout();
        }
    }
}