﻿// File: CustomerForm.cs
using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HardwareShopManagementSystem
{
    public partial class CustomerForm : Form
    {
        Database db = new Database();
        int selectedId = 0;

        public CustomerForm()
        {
            InitializeComponent();
        }

        private void CustomerForm_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        void LoadData()
        {
            try
            {
                using (SqlConnection con = db.GetConnection())
                {
                    con.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter("SELECT CustomerID, CustomerName, Phone, Address FROM Customers", con))
                    {
                        DataTable dt = new DataTable();
                        da.Fill(dt);
                        dgvCustomer.DataSource = dt;

                        dgvCustomer.Columns["CustomerID"].HeaderText = "ID";
                        dgvCustomer.Columns["CustomerName"].HeaderText = "Customer Name";
                        dgvCustomer.Columns["Phone"].HeaderText = "Phone";
                        dgvCustomer.Columns["Address"].HeaderText = "Address";
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error loading data: " + ex.Message);
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCustomer.Text))
            {
                MessageBox.Show("Enter Customer Name.");
                return;
            }

            try
            {
                using (SqlConnection con = db.GetConnection())
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(
                        "INSERT INTO Customers (CustomerName, Phone, Address) VALUES (@name, @phone, @address)", con))
                    {
                        cmd.Parameters.AddWithValue("@name", txtCustomer.Text.Trim());
                        cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                        cmd.Parameters.AddWithValue("@address", txtAddress.Text.Trim());
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Customer Added!");
                    }
                }
                LoadData();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error adding customer: " + ex.Message);
            }
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedId == 0)
            {
                MessageBox.Show("Select a customer to update.");
                return;
            }

            try
            {
                using (SqlConnection con = db.GetConnection())
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand(
                        "UPDATE Customers SET CustomerName=@name, Phone=@phone, Address=@address WHERE CustomerID=@id", con))
                    {
                        cmd.Parameters.AddWithValue("@name", txtCustomer.Text.Trim());
                        cmd.Parameters.AddWithValue("@phone", txtPhone.Text.Trim());
                        cmd.Parameters.AddWithValue("@address", txtAddress.Text.Trim());
                        cmd.Parameters.AddWithValue("@id", selectedId);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Customer Updated!");
                    }
                }
                LoadData();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error updating customer: " + ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == 0)
            {
                MessageBox.Show("Select a customer to delete.");
                return;
            }

            var confirm = MessageBox.Show("Are you sure you want to delete?", "Confirm Delete", MessageBoxButtons.YesNo);
            if (confirm != DialogResult.Yes) return;

            try
            {
                using (SqlConnection con = db.GetConnection())
                {
                    con.Open();
                    using (SqlCommand cmd = new SqlCommand("DELETE FROM Customers WHERE CustomerID=@id", con))
                    {
                        cmd.Parameters.AddWithValue("@id", selectedId);
                        cmd.ExecuteNonQuery();
                        MessageBox.Show("Customer Deleted!");
                    }
                }
                LoadData();
                ClearFields();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Error deleting customer: " + ex.Message);
            }
        }

        private void dgvCustomer_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                var row = dgvCustomer.Rows[e.RowIndex];
                selectedId = Convert.ToInt32(row.Cells["CustomerID"].Value);
                txtCustomer.Text = row.Cells["CustomerName"].Value.ToString();
                txtPhone.Text = row.Cells["Phone"].Value.ToString();
                txtAddress.Text = row.Cells["Address"].Value.ToString();
            }
        }

        void ClearFields()
        {
            txtCustomer.Clear();
            txtPhone.Clear();
            txtAddress.Clear();
            selectedId = 0;
        }
    }
}