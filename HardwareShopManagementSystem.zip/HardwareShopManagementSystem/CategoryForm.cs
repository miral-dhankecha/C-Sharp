﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HardwareShopManagementSystem
{
    public partial class CategoryForm : Form
    {
        int selectedId = 0;
        Database db = new Database();

        public CategoryForm()
        {
            InitializeComponent();
        }

        // ✅ FORM LOAD
        private void CategoryForm_Load(object sender, EventArgs e)
        {
            LoadData();
        }

        // ✅ LOAD DATA IN GRID
        void LoadData()
        {
            using (SqlConnection con = db.GetConnection())
            {
                try
                {
                    con.Open();
                    SqlDataAdapter da = new SqlDataAdapter("SELECT * FROM Categories", con);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dgvCategory.DataSource = dt;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // ✅ ADD CATEGORY
        private void btnAdd_Click(object sender, EventArgs e)
        {
            if (txtCategoryName.Text.Trim() == "")
            {
                MessageBox.Show("Please enter category name!");
                return;
            }

            using (SqlConnection con = db.GetConnection())
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("INSERT INTO Categories (CategoryName) VALUES (@name)", con);
                    cmd.Parameters.AddWithValue("@name", txtCategoryName.Text.Trim());

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Category Added Successfully!");
                    txtCategoryName.Clear();
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // ✅ GRID CLICK (FIXED ERROR)
        private void dgvCategory_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                // ❗ Ignore header click
                if (e.RowIndex >= 0)
                {
                    DataGridViewRow row = dgvCategory.Rows[e.RowIndex];

                    // ❗ NULL safety
                    if (row.Cells[0].Value != null && row.Cells[0].Value != DBNull.Value)
                    {
                        selectedId = Convert.ToInt32(row.Cells[0].Value);
                        txtCategoryName.Text = row.Cells[1].Value.ToString();
                    }
                }
            }
            catch (Exception)
            {
                MessageBox.Show("Invalid selection!");
            }
        }

        // ✅ UPDATE CATEGORY
        private void btnUpdate_Click(object sender, EventArgs e)
        {
            if (selectedId == 0)
            {
                MessageBox.Show("Please select a category to update!");
                return;
            }

            if (txtCategoryName.Text.Trim() == "")
            {
                MessageBox.Show("Please enter category name!");
                return;
            }

            using (SqlConnection con = db.GetConnection())
            {
                try
                {
                    con.Open();

                    SqlCommand cmd = new SqlCommand("UPDATE Categories SET CategoryName=@name WHERE CategoryID=@id", con);
                    cmd.Parameters.AddWithValue("@name", txtCategoryName.Text.Trim());
                    cmd.Parameters.AddWithValue("@id", selectedId);

                    cmd.ExecuteNonQuery();

                    MessageBox.Show("Category Updated Successfully!");
                    txtCategoryName.Clear();
                    selectedId = 0;
                    LoadData();
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }

        // ✅ DELETE CATEGORY
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (selectedId == 0)
            {
                MessageBox.Show("Please select a category to delete!");
                return;
            }

            DialogResult result = MessageBox.Show("Are you sure you want to delete?",
                                                 "Confirm",
                                                 MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                using (SqlConnection con = db.GetConnection())
                {
                    try
                    {
                        con.Open();

                        SqlCommand cmd = new SqlCommand("DELETE FROM Categories WHERE CategoryID=@id", con);
                        cmd.Parameters.AddWithValue("@id", selectedId);

                        cmd.ExecuteNonQuery();

                        MessageBox.Show("Category Deleted Successfully!");
                        txtCategoryName.Clear();
                        selectedId = 0;
                        LoadData();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error: " + ex.Message);
                    }
                }
            }
        }
    }
}