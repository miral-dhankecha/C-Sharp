﻿using System;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace HardwareShopManagementSystem
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        // ✅ Form Load
        private void LoginForm_Load(object sender, EventArgs e)
        {
            // (Optional) Database test hata bhi sakte ho later
        }

        // ✅ LOGIN BUTTON (FINAL WORKING)
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            // ❗ Empty check (important)
            if (username == "" || password == "")
            {
                MessageBox.Show("Please enter username and password!");
                return;
            }

            Database db = new Database();

            using (SqlConnection con = db.GetConnection())
            {
                try
                {
                    con.Open();

                    string query = "SELECT COUNT(*) FROM Users WHERE Username=@username AND Password=@password";

                    SqlCommand cmd = new SqlCommand(query, con);
                    cmd.Parameters.AddWithValue("@username", username);
                    cmd.Parameters.AddWithValue("@password", password);

                    int count = (int)cmd.ExecuteScalar();

                    if (count > 0)
                    {
                        MessageBox.Show("Login Successful!");

                        // ✅ DASHBOARD OPEN
                        DashboardForm dashboard = new DashboardForm();
                        dashboard.Show();

                        // ✅ LOGIN HIDE
                        this.Hide();
                    }
                    else
                    {
                        MessageBox.Show("Invalid Username or Password!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Error: " + ex.Message);
                }
            }
        }
    }
}