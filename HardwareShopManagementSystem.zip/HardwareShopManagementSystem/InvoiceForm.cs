﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Drawing.Printing;
using System.Windows.Forms;

namespace HardwareShopManagementSystem
{
    public partial class InvoiceForm : Form
    {
        Database db = new Database();
        int billId;
        DataTable billData = new DataTable();

        public InvoiceForm(int id)
        {
            InitializeComponent();
            billId = id;
        }

        private void InvoiceForm_Load(object sender, EventArgs e)
        {
            LoadInvoice();
        }

        private void LoadInvoice()
        {
            using (SqlConnection con = db.GetConnection())
            {
                con.Open();

                string query = @"
                SELECT i.ItemName, bi.Quantity, bi.Price, bi.Total
                FROM BillItems bi
                JOIN Items i ON bi.ItemID = i.ItemID
                WHERE bi.BillID = @billId";

                SqlDataAdapter da = new SqlDataAdapter(query, con);
                da.SelectCommand.Parameters.AddWithValue("@billId", billId);

                da.Fill(billData);

                dgvInvoice.DataSource = billData;
            }
        }

        private void btnPrint_Click(object sender, EventArgs e)
        {
            PrintDocument pd = new PrintDocument();
            pd.PrintPage += PrintPage;

            PrintPreviewDialog preview = new PrintPreviewDialog();
            preview.Document = pd;
            preview.ShowDialog();
        }

        private void PrintPage(object sender, PrintPageEventArgs e)
        {
            int y = 100;

            e.Graphics.DrawString("HARDWARE SHOP BILL", new Font("Arial", 18, FontStyle.Bold), Brushes.Black, 200, 50);

            foreach (DataRow row in billData.Rows)
            {
                string line = $"{row["ItemName"]}  Qty:{row["Quantity"]}  ₹{row["Total"]}";
                e.Graphics.DrawString(line, new Font("Arial", 12), Brushes.Black, 100, y);
                y += 30;
            }
        }
    }
}