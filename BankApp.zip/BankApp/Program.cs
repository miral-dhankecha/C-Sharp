﻿using System;

namespace BankApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Savings Account
            Savings s1 = new Savings(101, 5000, 5);
            s1.CheckBalance();
            s1.Deposit(1000);
            s1.Withdraw(2000);
            s1.ShowInterest();
            s1.CheckBalance();

            Console.WriteLine("---------------------");

            // Current Account
            Current c1 = new Current(202, 3000, 2000);
            c1.CheckBalance();
            c1.Deposit(500);
            c1.Withdraw(4000);
            c1.ShowOverdraft();
            c1.CheckBalance();

            Console.ReadLine();
        }
    }
}