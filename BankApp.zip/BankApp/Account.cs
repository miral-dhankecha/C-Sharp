﻿using System;

namespace BankApp
{
    public abstract class Account
    {
        protected int accountNo;
        protected double balance;

        // Constructor
        public Account(int accNo, double bal)
        {
            accountNo = accNo;
            balance = bal;
        }

        // Concrete Method
        public void CheckBalance()
        {
            Console.WriteLine("Account No: " + accountNo);
            Console.WriteLine("Balance: " + balance);
        }

        // Abstract Methods
        public abstract void Deposit(double amount);
        public abstract void Withdraw(double amount);
    }
}