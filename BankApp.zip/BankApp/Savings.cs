﻿using System;

namespace BankApp
{
    public class Savings : Account
    {
        private double interestRate;

        // Constructor
        public Savings(int accNo, double bal, double rate)
            : base(accNo, bal)
        {
            interestRate = rate;
        }

        public override void Deposit(double amount)
        {
            balance += amount;
            Console.WriteLine("Amount Deposited in Savings: " + amount);
        }

        public override void Withdraw(double amount)
        {
            if (amount <= balance)
            {
                balance -= amount;
                Console.WriteLine("Amount Withdrawn from Savings: " + amount);
            }
            else
            {
                Console.WriteLine("Insufficient Balance in Savings!");
            }
        }

        public void ShowInterest()
        {
            Console.WriteLine("Interest Rate: " + interestRate + "%");
        }
    }
}