﻿using System;

namespace BankApp
{
    public class Current : Account
    {
        private double overdraftLimit;

        // Constructor
        public Current(int accNo, double bal, double limit)
            : base(accNo, bal)
        {
            overdraftLimit = limit;
        }

        public override void Deposit(double amount)
        {
            balance += amount;
            Console.WriteLine("Amount Deposited in Current: " + amount);
        }

        public override void Withdraw(double amount)
        {
            if (amount <= balance + overdraftLimit)
            {
                balance -= amount;
                Console.WriteLine("Amount Withdrawn from Current: " + amount);
            }
            else
            {
                Console.WriteLine("Overdraft limit exceeded!");
            }
        }

        public void ShowOverdraft()
        {
            Console.WriteLine("Overdraft Limit: " + overdraftLimit);
        }
    }
}