﻿using System;
using System.Runtime.ConstrainedExecution;

namespace VehicleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // Create object of Car
            Car car1 = new Car("Four Wheeler", "SUV", "Toyota");

            // Call show method
            car1.Show();

            Console.ReadLine();
        }
    }
}