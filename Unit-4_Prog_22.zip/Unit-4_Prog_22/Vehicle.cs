﻿using System;

namespace VehicleApp
{
    public class Vehicle
    {
        // Instance variable
        protected string vehicle_type;

        // Constructor
        public Vehicle(string v_type)
        {
            vehicle_type = v_type;
        }

        // Show method
        public virtual void Show()
        {
            Console.WriteLine("Vehicle Type: " + vehicle_type);
        }
    }
}