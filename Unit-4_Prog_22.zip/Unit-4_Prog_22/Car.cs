﻿using System;

namespace VehicleApp
{
    public class Car : Vehicle
    {
        // Instance variables
        private string model_type;
        private string company_name;

        // Constructor
        public Car(string v_type, string model, string company)
            : base(v_type)
        {
            model_type = model;
            company_name = company;
        }

        // Overriding Show method
        public override void Show()
        {
            // Call base class method
            base.Show();

            Console.WriteLine("Company Name: " + company_name);
            Console.WriteLine("Model Type: " + model_type);
        }
    }
}